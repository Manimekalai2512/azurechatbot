import os
import streamlit as st
from datetime import datetime, timedelta, timezone
from typing import List, TypedDict, Optional, Any, Dict

# Azure Security & Clients
from azure.identity import DefaultAzureCredential
from azure.search.documents import SearchClient
from azure.storage.blob import generate_blob_sas, BlobSasPermissions
from langchain_openai import AzureChatOpenAI
from langchain_core.messages import HumanMessage, AIMessage, BaseMessage
from langgraph.graph import StateGraph, END

# --- 1. CONFIGURATION & SAFETY CHECKS ---
credential = DefaultAzureCredential()

def get_env_var(name: str) -> str:
    """Helper to ensure environment variables are not None"""
    val = os.getenv(name)
    if not val:
        return "" 
    return val

# Load Env Vars securely
SEARCH_ENDPOINT = get_env_var("AZURE_SEARCH_ENDPOINT")
SEARCH_INDEX = get_env_var("AZURE_SEARCH_INDEX")
BLOB_ACCOUNT_NAME = get_env_var("AZURE_BLOB_ACCOUNT_NAME")
BLOB_CONTAINER = get_env_var("AZURE_BLOB_CONTAINER_NAME")
BLOB_ACCOUNT_KEY = get_env_var("AZURE_BLOB_ACCOUNT_KEY")
OPENAI_ENDPOINT = get_env_var("AZURE_OPENAI_ENDPOINT")
OPENAI_DEPLOYMENT = "gpt-4o" 
OPENAI_API_VER = "2024-05-01-preview"

# --- 2. INITIALIZE CLIENTS ---
search_client = None
if SEARCH_ENDPOINT:
    try:
        search_client = SearchClient(SEARCH_ENDPOINT, SEARCH_INDEX, credential=credential)
    except Exception:
        search_client = None

# Initialize OpenAI
# We use 'deployment_name' and 'openai_api_version' to satisfy the Linter
llm = AzureChatOpenAI(
    deployment_name=OPENAI_DEPLOYMENT,
    openai_api_version=OPENAI_API_VER,
    azure_endpoint=OPENAI_ENDPOINT,
    azure_ad_token_provider=lambda: credential.get_token("https://cognitiveservices.azure.com/.default").token
)

# --- 3. THE SECURITY LOGIC ---
def generate_secure_link(file_name: str, external_url: Optional[str] = None) -> str:
    if external_url:
        return external_url

    if not file_name or not BLOB_ACCOUNT_NAME or not BLOB_ACCOUNT_KEY: 
        return "#"
    
    try:
        expiry_time = datetime.now(timezone.utc) + timedelta(minutes=30)
        
        sas_token = generate_blob_sas(
            account_name=BLOB_ACCOUNT_NAME,
            container_name=BLOB_CONTAINER,
            blob_name=file_name,
            account_key=BLOB_ACCOUNT_KEY,
            permission=BlobSasPermissions(read=True),
            expiry=expiry_time
        )
        return f"https://{BLOB_ACCOUNT_NAME}.blob.core.windows.net/{BLOB_CONTAINER}/{file_name}?{sas_token}"
    except Exception:
        return "#error"

# --- 4. LANGGRAPH SETUP ---
# Defining the structure of our Chat State
class ChatState(TypedDict):
    messages: List[BaseMessage]
    context: str
    references: List[dict]

def retrieve_documents(state: ChatState) -> Dict[str, Any]:
    # Safety check for empty messages
    if not state.get("messages"):
        return {"context": "No query provided.", "references": []}

    last_message = state["messages"][-1].content
    
    if not search_client:
        return {"context": "Search client not configured.", "references": []}

    try:
        # Using correct Azure fields
        results = search_client.search(
            search_text=str(last_message),
            top=3,
            select=["metadata_storage_name", "content"] 
        )
    except Exception as e:
        return {"context": f"Search Error: {str(e)}", "references": []}
    
    context_text = ""
    references = []
    
    for doc in results:
        actual_filename = str(doc.get("metadata_storage_name", ""))
        
        # Generate Link
        safe_link = generate_secure_link(actual_filename)
        
        content_snippet = str(doc.get('content', ''))[:1000]
        context_text += f"Document: {actual_filename}\nContent: {content_snippet}...\n\n"
        
        references.append({
            "name": actual_filename,
            "url": safe_link,
            "type": "📄 Document"
        })
    
    return {"context": context_text, "references": references}

def generate_answer(state: ChatState) -> Dict[str, Any]:
    if not state.get("messages"):
        return {"messages": []}

    question = state["messages"][-1].content
    context = state.get("context", "")
    
    prompt = f"""
    You are an expert Engineering Assistant.
    Answer the user's question based ONLY on the following context.
    
    Context:
    {context}
    
    User Question: {question}
    """
    
    response = llm.invoke(prompt)
    return {"messages": [response]}

# Build Graph
# We add type: ignore here because VS Code gets confused by TypedDict inheritance
workflow = StateGraph(ChatState) # type: ignore
workflow.add_node("retrieve", retrieve_documents)
workflow.add_node("generate", generate_answer)
workflow.set_entry_point("retrieve")
workflow.add_edge("retrieve", "generate")
workflow.add_edge("generate", END)
app = workflow.compile()

# --- 5. UI ---
st.set_page_config(page_title="ChatSFP Enterprise")
st.title("🔩 ChatSFP Engineering Assistant")

if "messages" not in st.session_state:
    st.session_state.messages = []

for msg in st.session_state.messages:
    if isinstance(msg, HumanMessage):
        st.chat_message("user").write(msg.content)
    elif isinstance(msg, AIMessage):
        st.chat_message("assistant").write(msg.content)

if prompt := st.chat_input("Enter Part Number..."):
    st.session_state.messages.append(HumanMessage(content=prompt))
    st.chat_message("user").write(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Searching..."):
            inputs = {"messages": st.session_state.messages}
            result = app.invoke(inputs)
            
            if result and "messages" in result and result["messages"]:
                ai_msg = result["messages"][-1]
                st.markdown(ai_msg.content)
                
                if result.get("references"):
                    st.markdown("### 📚 References")
                    for ref in result["references"]:
                        st.markdown(f"📄 **[{ref['name']}]({ref['url']})**")
                
                st.session_state.messages.append(ai_msg)
            else:
                st.error("No response generated.")